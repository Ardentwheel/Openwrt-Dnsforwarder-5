dnsforwarder
============

License :
GPL v3

Dependencies :

  For Linux:

    pthread;
    libcurl (optional);
    openssl (optional).

  For Windows:
  None.
    
Macros needed to be declared while compiling :

  For Linux:
  None.
    
  For Windows x86 (at least Windows XP)

    WIN32
    
  For Windows x86-64 (at least Windows Vista):

    WIN32
    WIN64
